// lib/screens/drivers_hub_page.dart
import 'dart:typed_data';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../services/driver_csv.dart';
import '../widgets/app_shell.dart';
import '../widgets/app_side_menu.dart';

class DriversHubPage extends StatefulWidget {
  const DriversHubPage({super.key});

  @override
  State<DriversHubPage> createState() => _DriversHubPageState();
}

class _DriversHubPageState extends State<DriversHubPage> {
  bool _busyCsv = false;
  String _search = '';

  String get _uid => FirebaseAuth.instance.currentUser!.uid;

  Stream<QuerySnapshot<Map<String, dynamic>>> _driversStream() {
    return FirebaseFirestore.instance
        .collection('users')
        .doc(_uid)
        .collection('drivers')
        .orderBy('driverName', descending: false)
        .snapshots();
  }

  // =============== CSV IMPORT ==================

  Future<void> _uploadDriverCsv() async {
    if (_busyCsv) return;
    setState(() => _busyCsv = true);

    try {
      final picked = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['csv'],
        withData: true,
      );
      if (picked == null || picked.files.isEmpty) {
        setState(() => _busyCsv = false);
        return;
      }

      final f = picked.files.single;
      final Uint8List? bytes = f.bytes;
      if (bytes == null) throw Exception('No file bytes');

      await DriverCsvService.importForUser(
        uid: _uid,
        csvBytes: bytes,
      );

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Driver CSV imported for your DSP (${f.name}).')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Driver CSV import failed: $e')),
      );
    } finally {
      if (mounted) setState(() => _busyCsv = false);
    }
  }

  // =============== MANUAL DRIVER CREATION ==================

  Future<void> _createDriverManually() async {
    final nameCtrl = TextEditingController();
    final idCtrl = TextEditingController();
    final emailCtrl = TextEditingController();

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Add Driver Manually'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameCtrl,
              decoration: const InputDecoration(
                labelText: 'Driver name',
              ),
            ),
            TextField(
              controller: idCtrl,
              decoration: const InputDecoration(
                labelText: 'Transporter / Driver ID',
              ),
            ),
            TextField(
              controller: emailCtrl,
              decoration: const InputDecoration(
                labelText: 'Email (optional, for contact)',
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('Save'),
          ),
        ],
      ),
    );

    if (ok != true) return;

    final name = nameCtrl.text.trim();
    final tid = idCtrl.text.trim();
    final email = emailCtrl.text.trim();

    if (tid.isEmpty || name.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Name and Transporter ID are required.')),
      );
      return;
    }

    final db = FirebaseFirestore.instance;
    final doc = db
        .collection('users')
        .doc(_uid)
        .collection('drivers')
        .doc(tid.toUpperCase());

    await doc.set({
      'transporterId': tid.toUpperCase(),
      'driverName': name,
      'email': email.isEmpty ? null : email,
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
      'hasLogin': false,
      'active': true,
    }, SetOptions(merge: true));

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Driver "$name" saved.')),
    );
  }

  // =============== ROW ACTIONS (CREATE / SUSPEND / DELETE) ==================

  Future<void> _onCreateOrResetLogin(
    DocumentSnapshot<Map<String, dynamic>> driverDoc,
  ) async {
    final data = driverDoc.data() ?? {};
    final name = (data['driverName'] ?? '').toString();
    final tid = (data['transporterId'] ?? '').toString();

    final pwdCtrl = TextEditingController();
    final pwd2Ctrl = TextEditingController();

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Set driver login'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Driver: ${name.isEmpty ? '(no name)' : name}\n'
              'Transporter ID: $tid\n\n'
              'This will set the login password for this driver.\n'
              'Share the Transporter ID + this password with the driver.',
              style: const TextStyle(fontSize: 13),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: pwdCtrl,
              decoration: const InputDecoration(
                labelText: 'Password',
              ),
              obscureText: true,
            ),
            const SizedBox(height: 8),
            TextField(
              controller: pwd2Ctrl,
              decoration: const InputDecoration(
                labelText: 'Confirm password',
              ),
              obscureText: true,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('Save'),
          ),
        ],
      ),
    );

    if (ok != true) return;

    final pwd = pwdCtrl.text.trim();
    final pwd2 = pwd2Ctrl.text.trim();

    if (pwd.isEmpty || pwd2.isEmpty || pwd != pwd2) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Passwords must match and not be empty.')),
      );
      return;
    }

    try {
      // Call Cloud Function to create / update the real Auth user.
      final callable =
          FirebaseFunctions.instance.httpsCallable('createDriverLogin');
      await callable.call(<String, dynamic>{
        'dspUid': _uid,
        'transporterId': tid,
        'password': pwd,
      });

      // Mark in Firestore that this driver now has a login.
      await driverDoc.reference.set({
        'hasLogin': true,
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Login set. Give driver:\nID: $tid\nPassword: $pwd',
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to set login: $e')),
      );
    }
  }

  Future<void> _onSuspendDriver(
    DocumentSnapshot<Map<String, dynamic>> driverDoc,
  ) async {
    await driverDoc.reference.set({
      'active': false,
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Driver suspended.')),
    );
  }

  Future<void> _onDeleteDriver(
    DocumentSnapshot<Map<String, dynamic>> driverDoc,
  ) async {
    final data = driverDoc.data() ?? {};
    final name = (data['driverName'] ?? '').toString();

    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete driver'),
        content: Text(
          'Are you sure you want to delete driver "$name"?\n'
          'This will remove them from your DSP list.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirm != true) return;

    await driverDoc.reference.delete();

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Driver deleted.')),
    );
  }

  // =============== UI ==================

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;

    final title = const Text('DRIVERS HUB');

    final actions = [
      Padding(
        padding: const EdgeInsets.only(right: 8),
        child: FilledButton.icon(
          onPressed: _busyCsv ? null : _uploadDriverCsv,
          icon: const Icon(Icons.upload_file),
          label: Text(_busyCsv ? 'Importing…' : 'Upload Driver CSV'),
        ),
      ),
      Padding(
        padding: const EdgeInsets.only(right: 16),
        child: OutlinedButton.icon(
          onPressed: _createDriverManually,
          icon: const Icon(Icons.person_add_alt_1),
          label: const Text('Add Driver'),
        ),
      ),
    ];

    final body = Container(
      color: const Color(0xFFF6F7F5),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Top row: title + search
            Row(
              children: [
                Expanded(
                  child: Text(
                    'Drivers Hub',
                    style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                          fontSize: 24,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 0.4,
                        ),
                  ),
                ),
                SizedBox(
                  width: w < 480 ? 200 : 260,
                  child: TextField(
                    decoration: const InputDecoration(
                      prefixIcon: Icon(Icons.search),
                      hintText: 'Search by name or ID…',
                      isDense: true,
                      border: OutlineInputBorder(),
                    ),
                    onChanged: (s) => setState(() => _search = s.trim().toLowerCase()),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            Expanded(
              child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                stream: _driversStream(),
                builder: (context, snap) {
                  if (snap.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  final docs = snap.data?.docs ?? [];

                  var filtered = docs;
                  if (_search.isNotEmpty) {
                    filtered = docs.where((d) {
                      final data = d.data();
                      final name = (data['driverName'] ?? '').toString().toLowerCase();
                      final tid = (data['transporterId'] ?? '').toString().toLowerCase();
                      return name.contains(_search) || tid.contains(_search);
                    }).toList();
                  }

                  if (filtered.isEmpty) {
                    return const Center(
                      child: Text(
                        'No drivers yet.\nImport a CSV or add a driver manually.',
                        textAlign: TextAlign.center,
                      ),
                    );
                  }

                  return LayoutBuilder(
                    builder: (context, cns) {
                      final isTight = cns.maxWidth < 720;

                      if (isTight) {
                        // mobile / tight layout → cards
                        return ListView.separated(
                          itemCount: filtered.length,
                          separatorBuilder: (_, __) => const SizedBox(height: 8),
                          itemBuilder: (_, i) {
                            final d = filtered[i];
                            final data = d.data();
                            final name = (data['driverName'] ?? '').toString();
                            final tid = (data['transporterId'] ?? '').toString();
                            final email = (data['email'] ?? '').toString();
                            final hasLogin = (data['hasLogin'] as bool?) ?? false;
                            final active = (data['active'] as bool?) ?? true;

                            return Card(
                              elevation: 0.5,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(16),
                              ),
                              child: ListTile(
                                title: Text(
                                  name.isEmpty ? '(No name)' : name,
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                subtitle: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    if (tid.isNotEmpty) Text('ID: $tid'),
                                    if (email.isNotEmpty) Text('Email: $email'),
                                    const SizedBox(height: 4),
                                    Row(
                                      children: [
                                        _StatusChip(
                                          label: active ? 'Active' : 'Inactive',
                                          color: active
                                              ? const Color(0xFF16A34A)
                                              : Colors.grey,
                                        ),
                                        const SizedBox(width: 8),
                                        _StatusChip(
                                          label: hasLogin ? 'Login created' : 'No login yet',
                                          color: hasLogin
                                              ? const Color(0xFF2563EB)
                                              : Colors.orange,
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        );
                      }

                      // desktop / tablet: table style
                      return SingleChildScrollView(
                        child: DataTable(
                          headingTextStyle: const TextStyle(
                            fontWeight: FontWeight.w800,
                          ),
                          columns: const [
                            DataColumn(label: Text('Driver Name')),
                            DataColumn(label: Text('Transporter ID')),
                            DataColumn(label: Text('Email')),
                            DataColumn(label: Text('Status')),
                            DataColumn(label: Text('Login')),
                            DataColumn(label: Text('Actions')),
                          ],
                          rows: filtered.map((d) {
                            final data = d.data();
                            final name = (data['driverName'] ?? '').toString();
                            final tid = (data['transporterId'] ?? '').toString();
                            final email = (data['email'] ?? '').toString();
                            final hasLogin = (data['hasLogin'] as bool?) ?? false;
                            final active = (data['active'] as bool?) ?? true;

                            return DataRow(
                              cells: [
                                DataCell(Text(name.isEmpty ? '(No name)' : name)),
                                DataCell(Text(tid)),
                                DataCell(Text(email)),
                                DataCell(Text(active ? 'Active' : 'Inactive')),
                                DataCell(Text(hasLogin ? 'Created' : 'Not created')),
                                DataCell(
                                  Row(
                                    children: [
                                      _DriverActionButton(
                                        label: 'Create',
                                        color: const Color(0xFF16A34A),
                                        onPressed: () => _onCreateOrResetLogin(d),
                                      ),
                                      const SizedBox(width: 8),
                                      _DriverActionButton(
                                        label: 'Suspend',
                                        color: Colors.black87,
                                        onPressed: () => _onSuspendDriver(d),
                                      ),
                                      const SizedBox(width: 8),
                                      _DriverActionButton(
                                        label: 'Delete',
                                        color: const Color(0xFFDC2626),
                                        onPressed: () => _onDeleteDriver(d),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            );
                          }).toList(),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );

    return AppShell(
      menuWidth: 280,
      sideMenu: const AppSideMenu(
        width: 280,
        active: AppNav.drivers,
      ),
      title: title,
      actions: actions,
      body: body,
    );
  }
}

class _StatusChip extends StatelessWidget {
  final String label;
  final Color color;
  const _StatusChip({required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        label,
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w700,
          color: color,
        ),
      ),
    );
  }
}

class _DriverActionButton extends StatelessWidget {
  final String label;
  final Color color;
  final VoidCallback onPressed;

  const _DriverActionButton({
    required this.label,
    required this.color,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return TextButton(
      style: TextButton.styleFrom(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        backgroundColor: color,
        foregroundColor: Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(999),
        ),
        tapTargetSize: MaterialTapTargetSize.shrinkWrap,
        minimumSize: const Size(0, 0),
      ),
      onPressed: onPressed,
      child: Text(
        label,
        style: const TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}
