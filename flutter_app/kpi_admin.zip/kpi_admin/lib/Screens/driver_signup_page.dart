// lib/screens/driver_signup_page.dart
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class DriverSignupPage extends StatefulWidget {
  const DriverSignupPage({super.key});

  @override
  State<DriverSignupPage> createState() => _DriverSignupPageState();
}

class _DriverSignupPageState extends State<DriverSignupPage> {
  final _formKey = GlobalKey<FormState>();

  final _emailCtrl = TextEditingController();
  final _tidCtrl = TextEditingController();
  final _pwdCtrl = TextEditingController();
  final _pwd2Ctrl = TextEditingController();

  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _emailCtrl.dispose();
    _tidCtrl.dispose();
    _pwdCtrl.dispose();
    _pwd2Ctrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;

    final email = _emailCtrl.text.trim();
    final tidRaw = _tidCtrl.text.trim();
    final tid = tidRaw.toUpperCase();
    final pwd = _pwdCtrl.text.trim();

    setState(() {
      _busy = true;
      _error = null;
    });

    try {
      final db = FirebaseFirestore.instance;

      // 1) Find driver document registered by a DSP
      final q = await db
          .collectionGroup('drivers')
          .where('transporterId', isEqualTo: tid)
          .where('email', isEqualTo: email)
          .limit(1)
          .get();

      if (q.docs.isEmpty) {
        setState(() {
          _error =
              'No driver found for this email + Transporter ID.\n'
              'Please ask your DSP admin to register you.';
          _busy = false;
        });
        return;
      }

      final driverDoc = q.docs.first;
      final driverData = driverDoc.data();
      final hasLogin = (driverData['hasLogin'] as bool?) ?? false;
      if (hasLogin) {
        setState(() {
          _error =
              'A login already exists for this driver.\n'
              'Try using "Forgot password" on the login page.';
          _busy = false;
        });
        return;
      }

      // dspUid = parent of 'drivers' collection
      final dspUserRef = driverDoc.reference.parent.parent;
      if (dspUserRef == null) {
        setState(() {
          _error = 'Internal error: DSP reference missing.';
          _busy = false;
        });
        return;
      }
      final dspUid = dspUserRef.id;

      // 2) Create Firebase Auth user
      final auth = FirebaseAuth.instance;
      final cred = await auth.createUserWithEmailAndPassword(
        email: email,
        password: pwd,
      );
      final user = cred.user;
      if (user == null) {
        setState(() {
          _error = 'Error creating user account. Please try again.';
          _busy = false;
        });
        return;
      }
      final uid = user.uid;

      // Optional: send email verification if you want
      // await user.sendEmailVerification();

      // 3) Create /users/{uid} profile
      final driverName = (driverData['driverName'] ?? '').toString();
      await db.collection('users').doc(uid).set({
        'role': 'driver',
        'email': email,
        'transporterId': tid,
        'driverName': driverName,
        'dspUid': dspUid,
        'approved': true, // driver can log in immediately
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));

      // 4) Update driver doc to link Auth user
      await driverDoc.reference.set({
        'hasLogin': true,
        'invitePending': false,
        'authUid': uid,
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Driver account created. You can now log in.'),
        ),
      );

      // 5) Go back to login page
      Navigator.of(context).pushReplacementNamed('/login');
    } on FirebaseAuthException catch (e) {
      String msg = 'Authentication error.';
      if (e.code == 'email-already-in-use') {
        msg =
            'This email is already used.\n'
            'If it is yours, try the login page and use "Forgot password".';
      } else if (e.code == 'weak-password') {
        msg = 'Password is too weak. Choose a stronger password.';
      } else if (e.code == 'invalid-email') {
        msg = 'Invalid email address.';
      }
      setState(() {
        _error = msg;
        _busy = false;
      });
    } catch (e) {
      setState(() {
        _error = 'Something went wrong: $e';
        _busy = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final cardWidth = w < 480 ? w - 32 : 420.0;

    return Scaffold(
      body: Center(
        child: Card(
          elevation: 4,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          child: SizedBox(
            width: cardWidth,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 26),
              child: Form(
                key: _formKey,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text(
                      'Driver First-Time Signup',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 6),
                    const Text(
                      'Use the email + Transporter ID your DSP admin gave you.',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 12, color: Colors.black54),
                    ),
                    const SizedBox(height: 18),

                    TextFormField(
                      controller: _emailCtrl,
                      decoration: const InputDecoration(
                        labelText: 'Email',
                        prefixIcon: Icon(Icons.email_outlined),
                        border: OutlineInputBorder(),
                      ),
                      keyboardType: TextInputType.emailAddress,
                      validator: (v) {
                        final s = v?.trim() ?? '';
                        if (s.isEmpty) return 'Email is required.';
                        if (!s.contains('@')) return 'Enter a valid email.';
                        return null;
                      },
                    ),
                    const SizedBox(height: 12),

                    TextFormField(
                      controller: _tidCtrl,
                      decoration: const InputDecoration(
                        labelText: 'Transporter / Driver ID',
                        prefixIcon: Icon(Icons.badge_outlined),
                        border: OutlineInputBorder(),
                      ),
                      validator: (v) {
                        final s = v?.trim() ?? '';
                        if (s.isEmpty) return 'Transporter ID is required.';
                        return null;
                      },
                    ),
                    const SizedBox(height: 12),

                    TextFormField(
                      controller: _pwdCtrl,
                      decoration: const InputDecoration(
                        labelText: 'Password',
                        prefixIcon: Icon(Icons.lock_outline),
                        border: OutlineInputBorder(),
                      ),
                      obscureText: true,
                      validator: (v) {
                        final s = v ?? '';
                        if (s.length < 6) {
                          return 'Password must be at least 6 characters.';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 12),

                    TextFormField(
                      controller: _pwd2Ctrl,
                      decoration: const InputDecoration(
                        labelText: 'Confirm password',
                        prefixIcon: Icon(Icons.lock_outline),
                        border: OutlineInputBorder(),
                      ),
                      obscureText: true,
                      validator: (v) {
                        if (v != _pwdCtrl.text) {
                          return 'Passwords do not match.';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 16),

                    if (_error != null) ...[
                      Text(
                        _error!,
                        style: const TextStyle(
                          color: Colors.red,
                          fontSize: 12,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 10),
                    ],

                    SizedBox(
                      width: double.infinity,
                      child: FilledButton(
                        onPressed: _busy ? null : _submit,
                        child: _busy
                            ? const SizedBox(
                                height: 18,
                                width: 18,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  valueColor: AlwaysStoppedAnimation(Colors.white),
                                ),
                              )
                            : const Text('Create account'),
                      ),
                    ),
                    const SizedBox(height: 8),

                    TextButton(
                      onPressed: _busy
                          ? null
                          : () {
                              Navigator.of(context).pushReplacementNamed('/login');
                            },
                      child: const Text('Back to Login'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
