class AppConfig {
  // TODO: replace with your actual Render URL (it must end with /parse)
  static const parserUrl = 'https://score-parser.onrender.com/parse';
}
// # https://score-parser.onrender.com
// http://127.0.0.1:8000