
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class DriverScorecardTab extends StatelessWidget {
  final String dspUid;
  final DocumentReference driverDoc;

  const DriverScorecardTab({
    super.key,
    required this.dspUid,
    required this.driverDoc,
  });

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<DocumentSnapshot>(
      future: driverDoc.get(),
      builder: (context, snap) {
        if (!snap.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final driverData = snap.data!.data() as Map<String, dynamic>;
        final tid = driverData['transporterId'];

        return _LatestReportView(dspUid: dspUid, tid: tid);
      },
    );
  }
}

class _LatestReportView extends StatelessWidget {
  final String dspUid;
  final String tid;

  const _LatestReportView({
    required this.dspUid,
    required this.tid,
  });

  @override
  Widget build(BuildContext context) {
    final reports = FirebaseFirestore.instance
        .collection('users')
        .doc(dspUid)
        .collection('reports')
        .orderBy('reportDate', descending: true)
        .limit(1)
        .snapshots();

    return StreamBuilder<QuerySnapshot>(
      stream: reports,
      builder: (context, snap) {
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        if (snap.data!.docs.isEmpty) {
          return const Center(child: Text("No reports yet"));
        }

        final report = snap.data!.docs.first;
        final reportRef = report.reference;
        final summary = report['summary'] ?? {};

        return _ScorecardContent(
          dspUid: dspUid,
          tid: tid,
          summary: summary,
          reportRef: reportRef,
        );
      },
    );
  }
}

class _ScorecardContent extends StatelessWidget {
  final String dspUid;
  final String tid;
  final Map<String, dynamic> summary;
  final DocumentReference reportRef;

  const _ScorecardContent({
    required this.dspUid,
    required this.tid,
    required this.summary,
    required this.reportRef,
  });

  @override
  Widget build(BuildContext context) {
    final overallScore = summary['FinalScore'] ?? '--';
    final stationRank = summary['rankAtStation'] ?? '--';
    final stationCount = summary['stationCount'] ?? '--';
    final reliability =
        summary['reliabilityScore'] ?? summary['reliabilityNextDay'] ?? '--';

    return ListView(
      padding: const EdgeInsets.all(24),
      children: [
        Text(
          "Scorecard Week",
          style: Theme.of(context).textTheme.headlineSmall!.copyWith(
                fontWeight: FontWeight.bold,
              ),
        ),
        const SizedBox(height: 20),
        Row(
          children: [
            _summaryCard("Total Company Score", overallScore.toString()),
            const SizedBox(width: 16),
            _summaryCard(
                "Rank in Station", "$stationRank / $stationCount"),
            const SizedBox(width: 16),
            _summaryCard("Reliability Score", reliability.toString()),
          ],
        ),
        const SizedBox(height: 30),
        Text(
          "Drivers Performance",
          style: Theme.of(context).textTheme.titleLarge,
        ),
        const SizedBox(height: 20),
        _DriverList(
          dspUid: dspUid,
          tid: tid,
          reportRef: reportRef,
        ),
      ],
    );
  }
}

Widget _summaryCard(String title, String value) {
  return Expanded(
    child: Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: const [
          BoxShadow(
            blurRadius: 6,
            color: Colors.black12,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w500,
              )),
          const SizedBox(height: 8),
          Text(
            value,
            style: const TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    ),
  );
}

class _DriverList extends StatelessWidget {
  final String dspUid;
  final String tid;
  final DocumentReference reportRef;

  const _DriverList({
    required this.dspUid,
    required this.tid,
    required this.reportRef,
  });

  @override
  Widget build(BuildContext context) {
    final scores = FirebaseFirestore.instance
        .collection('users')
        .doc(dspUid)
        .collection('scores')
        .where('reportRef', isEqualTo: reportRef)
        .orderBy('rank')
        .snapshots();

    return StreamBuilder<QuerySnapshot>(
      stream: scores,
      builder: (context, snap) {
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final docs = snap.data!.docs;

        return Column(
          children: docs.map((d) {
            final data = d.data() as Map<String, dynamic>;
            final driverTid = data['transporterId'];
            final comp = data['comp'] ?? {};
            final kpis = data['kpis'] ?? {};

            return _driverRow(
              tid: driverTid,
              comp: comp,
              kpis: kpis,
              highlight: (driverTid == tid),
            );
          }).toList(),
        );
      },
    );
  }
}

Widget _driverRow({
  required String tid,
  required Map<String, dynamic> comp,
  required Map<String, dynamic> kpis,
  required bool highlight,
}) {
  return Container(
    margin: const EdgeInsets.only(bottom: 10),
    padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(
      color: highlight ? Colors.blue.shade50 : Colors.white,
      borderRadius: BorderRadius.circular(14),
      boxShadow: const [
        BoxShadow(blurRadius: 4, color: Colors.black12),
      ],
    ),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          tid,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
        Text((comp['FinalScore'] ?? '--').toString()),
        Text((kpis['Delivered'] ?? '--').toString()),
        Text((kpis['DNR'] ?? '--').toString()),
        Text((kpis['LoR'] ?? '--').toString()),
        Text((kpis['CDF'] ?? '--').toString()),
      ],
    ),
  );
}

