
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../screens/home_page.dart';
import '../screens/driver_home_page.dart';

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }
        if (!snap.hasData || snap.data == null) {
          return const _LoginRedirect();
        }

        final user = snap.data!;
        final email = user.email ?? "";

        return FutureBuilder<QuerySnapshot>(
          future: FirebaseFirestore.instance
              .collectionGroup('drivers')
              .where('email', isEqualTo: email)
              .limit(1)
              .get(),
          builder: (context, driverSnap) {
            if (driverSnap.connectionState == ConnectionState.waiting) {
              return const Scaffold(
                body: Center(child: CircularProgressIndicator()),
              );
            }

            if (driverSnap.hasData && driverSnap.data!.docs.isNotEmpty) {
              final doc = driverSnap.data!.docs.first;
              final dspUid = doc.reference.parent.parent!.id;
              return DriverHomePage(
                dspUid: dspUid,
                driverDoc: doc.reference,
              );
            }

            return const HomePage();
          },
        );
      },
    );
  }
}

class _LoginRedirect extends StatelessWidget {
  const _LoginRedirect();

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(child: Text("Please login.")),
    );
  }
}
