
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../widgets/app_shell.dart';
import 'driver_scorecard_tab.dart';
import 'onboarding_tab.dart';

class DriverHomePage extends StatefulWidget {
  final String dspUid;
  final DocumentReference driverDoc;

  const DriverHomePage({
    super.key,
    required this.dspUid,
    required this.driverDoc,
  });

  @override
  State<DriverHomePage> createState() => _DriverHomePageState();
}

class _DriverHomePageState extends State<DriverHomePage> {
  int _page = 0;

  @override
  Widget build(BuildContext context) {
    return AppShell(
      selectedIndex: _page,
      onSelect: (i) {
        setState(() => _page = i);
      },
      sideMenuItems: const [
        "Score Card Dashboard",
        "Onboarding",
      ],
      child: _page == 0
          ? DriverScorecardTab(
              dspUid: widget.dspUid,
              driverDoc: widget.driverDoc,
            )
          : OnboardingTab(driverDoc: widget.driverDoc),
    );
  }
}
